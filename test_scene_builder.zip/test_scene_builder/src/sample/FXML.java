package sample;

public @interface FXML {
}
