package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;

import java.util.Observable;

public class Controller {
    public Label helloWorld;
    public ChoiceBox<String> choicebx;
    public Label choicelabel;

    ObservableList<String> txlist = FXCollections.observableArrayList("ULXTE-2", "ULXTE-4", "ULXTE-6", "ULXTE-150");

    @FXML
    public void initialize() {
        choicebx.getItems().addAll(txlist);
    }



    public void sayHelloWorld(ActionEvent actionEvent) {
        helloWorld.setText("Hello wolrd!!!!");
    }

    public void whatsonchoice(ActionEvent actionEvent) {
        String txString = (String) choicebx.getValue();
        choicelabel.setText(txString);
    }
    }

